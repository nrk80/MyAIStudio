# My AI Studio — Android Starter v1

A free, offline-first Android starter for a personal video-creation workflow.

## Included
- Home workspace and research niche selector
- Video idea entry
- Shorts and long-video workflow notes
- Local approval demo; no automatic publishing

## Important limitations
This starter is not yet an AI-powered video generator. Live trend research, fact checking, AI script writing, voice generation, video rendering, thumbnails, cloud storage and YouTube OAuth/upload are not connected. Verify claims and media rights before publishing.

## Build
Requires JDK 17 and Gradle 8.9 (or Android Studio with compatible Gradle tooling). Run `gradle :app:assembleDebug` from this directory.
