package com.example.myaistudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyAIStudioApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyAIStudioApp() {
    var selected by remember { mutableStateOf("All niches") }
    var idea by remember { mutableStateOf("") }
    var approved by remember { mutableStateOf(false) }
    val categories = listOf("All niches", "Technology", "Facts", "Entertainment", "Education", "Gaming", "Stories")
    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("My AI Studio") }) }) { padding ->
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item { Text("Your personal video creation workspace", style = MaterialTheme.typography.titleMedium) }
                item {
                    Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Research desk", style = MaterialTheme.typography.titleLarge)
                        Text("Choose a content niche")
                        categories.forEach { category ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(category)
                                RadioButton(selected = selected == category, onClick = { selected = category })
                            }
                        }
                        Text("Selected: $selected")
                    } }
                }
                item {
                    Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Video idea", style = MaterialTheme.typography.titleLarge)
                        OutlinedTextField(value = idea, onValueChange = { idea = it }, label = { Text("Enter your video idea") }, modifier = Modifier.fillMaxWidth())
                        Text("Planned formats: Shorts (30–60 sec) and long videos (10–15 min).")
                    } }
                }
                item {
                    Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Approval queue", style = MaterialTheme.typography.titleLarge)
                        Text(if (approved) "Your draft is marked approved locally." else "Nothing will be uploaded without your approval.")
                        Button(onClick = { approved = !approved }, enabled = idea.isNotBlank()) { Text(if (approved) "Undo approval" else "Approve draft") }
                    } }
                }
                item { Text("Starter version: templates and local demo only. AI research, voice, video rendering and YouTube upload will be added in later versions.", style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
}
